
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const proyectos = [
  {
    titulo: "Todos los proyectos",
    imagen: "/images/proyectos/01-Todos los proyectos.png",
    resumen: "Conoce el conjunto de iniciativas solidarias que impulsamos desde CSJM. Cada mes, un nuevo proyecto necesita de ti.",
  },
  {
    titulo: "Proyecto Febrero",
    imagen: "/images/proyectos/02-CSJM-POSTER FEBRERO.png",
    resumen: "Apoyo alimentario y educativo en comunidades vulnerables.",
  },
  {
    titulo: "Proyecto Marzo",
    imagen: "/images/proyectos/03-CSJM - Poster Marzo.png",
    resumen: "Educación técnica para jóvenes sin recursos en zonas rurales.",
  },
  {
    titulo: "Proyecto Abril",
    imagen: "/images/proyectos/04-CSJM - Poster ABRIL.png",
    resumen: "Sostenimiento de internados para jóvenes indígenas.",
  },
  {
    titulo: "Proyecto Mayo",
    imagen: "/images/proyectos/05-CSJM - Poster MAYO.png",
    resumen: "Formación profesional en sectores sanitarios para jóvenes mujeres.",
  },
  {
    titulo: "Proyecto Junio",
    imagen: "/images/proyectos/06-CSJM - Poster JUNIO.png",
    resumen: "Educación integral con enfoque ecológico en zonas amazónicas.",
  },
  {
    titulo: "Proyecto Septiembre",
    imagen: "/images/proyectos/07-CSJM - Poster SEPTIEMBRE.png",
    resumen: "Reconstrucción de espacios educativos tras desastres naturales.",
  }
];

export default function LandingPageCSJM() {
  return (
    <div className="p-6 space-y-8 max-w-7xl mx-auto">
      <header className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Un mes, un proyecto, una oportunidad para transformar vidas</h1>
        <p className="text-lg text-gray-600">Descubre cómo puedes colaborar con los proyectos solidarios de CSJM – Salesianos y marcar la diferencia.</p>
        <Button className="text-lg px-6 py-3">💙 Dona ahora</Button>
      </header>

      <section className="grid md:grid-cols-3 gap-6">
        {proyectos.map((p, i) => (
          <Card key={i} className="hover:shadow-xl transition-shadow">
            <img src={p.imagen} alt={p.titulo} className="w-full h-48 object-cover rounded-t-2xl" />
            <CardContent className="space-y-2 p-4">
              <h2 className="text-xl font-semibold">{p.titulo}</h2>
              <p className="text-sm text-gray-600">{p.resumen}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="bg-blue-50 p-6 rounded-2xl text-center space-y-4">
        <h2 className="text-2xl font-bold">¿Cómo puedes donar?</h2>
        <p className="text-md">Puedes colaborar de forma segura usando Bizum, transferencia o nuestro formulario de donación. Todas las aportaciones se reparten entre los proyectos activos de forma proporcional y transparente.</p>
        <div className="space-y-2">
          <p><strong>Bizum:</strong> Código 12345 – Concepto: CSJM</p>
          <p><strong>Transferencia:</strong> ES00 1234 5678 9012 3456 7890</p>
          <Button className="bg-green-600 hover:bg-green-700">Abrir formulario de donación</Button>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-10">
        © 2025 CSJM – Salesianos · Aviso legal · Política de privacidad
      </footer>
    </div>
  );
}
